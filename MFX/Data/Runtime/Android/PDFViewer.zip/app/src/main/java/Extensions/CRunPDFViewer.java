/* Copyright (c) 2019 Conceptgame */
package Extensions;

import Actions.CActExtension;
import Application.CRunApp;
import Banks.CImage;
import Conditions.CCndExtension;
import Expressions.CValue;
import OpenGL.GLRenderer;
import RunLoop.CCreateObjectInfo;
import RunLoop.CObjInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;
import Runtime.Log;
import Extensions.CRunExtension;

import android.graphics.pdf.PdfRenderer;
import android.graphics.Bitmap;
import android.os.ParcelFileDescriptor;
import android.Manifest;
import java.io.IOException;
import java.util.HashMap;
import java.io.File;

public class CRunPDFViewer extends CRunExtension
{
	/**
     * File descriptor of the PDF.
     */
    private ParcelFileDescriptor mFileDescriptor;

    /**
     * {@link android.graphics.pdf.PdfRenderer} to render the PDF.
     */
    private PdfRenderer mPdfRenderer;

    /**
     * Page that is currently shown on the screen.
     */
    private PdfRenderer.Page mCurrentPage;
	private int mCurrentImageNumber;
	private String mFilename;
	private boolean visible;
	private boolean pdfloaded;
	private CImage mImage;
	private CValue expRet;
	private HashMap<String, String> permissionsApi23;
	private boolean enabled_perms;
	private String mLastError;
	
	public CRunPDFViewer() {
		expRet = new CValue(0);
	}
	
	@Override 
	public int getNumberOfConditions()
	{
		return 1;
	}
	
    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
		pdfloaded = false;
		visible = true;
		mFilename = "";
		mCurrentImageNumber = -1;
		mLastError = "";
		
		if(MMFRuntime.deviceApi > 22) {
			permissionsApi23 = new HashMap<String, String>();
			permissionsApi23.put(Manifest.permission.READ_EXTERNAL_STORAGE, "Read Storage");
			if(!MMFRuntime.inst.verifyOkPermissionsApi23(permissionsApi23)){
				//MMFRuntime.inst.pushForPermissions(permissionsApi23, PERMISSIONS_PICA_REQUEST);
			}
			else{
				enabled_perms = true;
			}
		}
		else{
			enabled_perms = true;
		}		
        return false;
    }

    @Override
    public void displayRunObject()
    {
    	if (pdfloaded && visible)
    	{
    		if (mImage == null){
				mLastError = "Cannot render, image is null";
    		return;}

    		int drawX = ho.hoX;
    		int drawY = ho.hoY;

      		drawX -= rh.rhWindowX;
			drawY -= rh.rhWindowY;

			mImage.setResampling(ho.bAntialias);
			Log.Log("image is : " + mImage.getWidth() + ";" + mImage.getHeight() );
			Log.Log("render image at : " + drawX + ";" + drawY );
			GLRenderer.inst.renderImage(mImage, drawX, drawY, -1, -1, 0, 0);
    		//GLRenderer.inst.renderImage(image, drawX, drawY, image.getWidth(), image.getHeight(), 0, 0);

    	}
    }
    
    @Override
    public void pauseRunObject() { }
    
    @Override
    public void continueRunObject() {

    }
    
    @Override
    public void getZoneInfos()
    {
    	if (pdfloaded)
    	{
			if (mImage != null)
            {
			    ho.hoImgWidth = mImage.getWidth();
			    ho.hoImgHeight = mImage.getHeight();
            }
    	}
    	else
    	{
    		ho.hoImgWidth = 1;
    		ho.hoImgHeight = 1;
    	}
    }
    
    @Override
    public boolean condition (int num, CCndExtension cnd)
    {
    	switch (num)
    	{
    	case 0:
			return pdfloaded;  		
    	};
    	
    	return false;
    }
    
    @Override
    public void action (int num, CActExtension act)
    {
    	switch (num)
    	{
			case 0:
    		{
				String fileName = act.getParamFilename(rh, 0);
				mFilename = fileName;
				try {
					mLastError = "Loading file...";
					Log.Log("Loading file: " + mFilename);
					openRenderer(mFilename);
					if(pdfloaded)
					{
						mLastError = "File loaded.";
						Log.Log("File loaded." + mFilename);
						mCurrentImageNumber = 0;
						renderPage(0);
					}
					else
					{
						mLastError = "Cannot load file "+mFilename;
					}
				} 
				catch (Exception e) {
					mLastError = e.toString();
				}
				return;
			}
			case 1:
    		{
				try{
					closeRenderer();
				}
				catch (Exception e) {
					mLastError = e.toString();
				}
			}
    		case 2:
    		{
				int nimage = act.getParamExpression (rh, 0);
				
				if (nimage >= 0 && mPdfRenderer!=null)
				{
					try
					{
						mCurrentImageNumber = nimage;
						renderPage(mCurrentImageNumber);
						//ho.redisplay();
						//ho.modif();
					}
					catch(Exception e)
					{
						Log.Log("Exception: "+e.toString());
						mLastError = e.toString();
					}
				}
				else
				{
					mLastError = "Cannot set current page";
				}
				
				return;
			}
    		
    		/*case 2:    			
    		{
				ho.hoX = act.getParamExpression(rh, 0);
				ho.hoY = act.getParamExpression(rh, 1);
				ho.redisplay();
				ho.modif();
				
				return;
    		}

    		case 3:
    		{
    			visible = true;
    			return;
    		}

    		case 4:
    		{
    			visible = false;
    			return;
    		}*/
    	};    	
    }
    
    @Override
    public CValue expression (int num)
    {
    	switch (num)
    	{
	    	case 0:
			{
				String error = mLastError;
	    		expRet.forceString(error);
				return expRet;
			}
			case 1:
			{
				if(mPdfRenderer!=null)
				{
					expRet.forceInt(mPdfRenderer.getPageCount());
				}
				else{
					expRet.forceInt(0);
				}
	    		return expRet;
			}
			case 2:
			{
	    		expRet.forceInt(mCurrentImageNumber+1);
	    		return expRet;
			}
			
    	};   	
    	return expRet;
    }
	
	/**
     * Sets up a {@link android.graphics.pdf.PdfRenderer} and related resources.
     */
    private void openRenderer(String filename) throws IOException {
		if(filename != null && filename.length() > 0) 
		{
			pdfloaded = false;
			File file = new File(filename);
			Log.Log("open pdf.");
			mFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
			// This is the PdfRenderer we use to render the PDF.
			if (mFileDescriptor != null) {
				mPdfRenderer = new PdfRenderer(mFileDescriptor);
			}
			else
			{
				mLastError = "File Descriptor is null";
			}
			pdfloaded = true;
		}
		else
		{
			mLastError = "File name is empty or null";
		}
    }
	
	private void renderPage(int index) {

		if (index >= mPdfRenderer.getPageCount()) {
            mLastError = "index bigger than number of pages in pdf";
			return;
        }

        // Make sure to close the current page before opening another one.
        if (null != mCurrentPage) {
            mCurrentPage.close();
        }
        
		// Use `openPage` to open a specific page in PDF.
		Log.Log("opening pdf page...");
		mCurrentPage = mPdfRenderer.openPage(index);
		// Important: the destination bitmap must be ARGB (not RGB).
		Log.Log("creating bitmap...");
		Bitmap bitmap = Bitmap.createBitmap(mCurrentPage.getWidth(), mCurrentPage.getHeight(),Bitmap.Config.ARGB_8888);
		// Here, we render the page onto a Bitmap.
		// To render a portion of the page, use the second and third parameter. Pass nulls to get the default result.
		Log.Log("redering pdf page...");
		mCurrentPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
		// Create image
		if(bitmap != null)
		{
			Log.Log("Creating image");
			// Create image
			int xHS = 0;
			int yHS = 0;
			int xAP = 0;
			int yAP = 0;
			short newImg = this.rh.rhApp.imageBank.addImage(bitmap, (short) xHS, (short) yHS, (short) xAP, (short) yAP, true);

			if(newImg!=-1)
			{
				mImage = this.ho.getImageBank().getImageFromHandle(newImg);
			}
		}
		else
		{
			mLastError = "Page cannot be rendered, bitmap is null";
			Log.Log("Page cannot be rendered, bitmap is null");
		}
    }

    /**
     * Closes the {@link android.graphics.pdf.PdfRenderer} and related resources.
     *
     * @throws java.io.IOException When the PDF file cannot be closed.
     */
    private void closeRenderer() throws IOException {
        if (null != mCurrentPage) {
            mCurrentPage.close();
        }
        mPdfRenderer.close();
        mFileDescriptor.close();
    }
}
